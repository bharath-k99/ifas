// Summary: this file will export multiple actions on online exam.
export * from './online_exam/index_change/index-change-actions';
export * from './online_exam/index_change/handle-question-pallete';
export * from './online_exam/handle_answer/option-color-change';
export * from './timer/timer-action';
export * from './online_exam/index_change/exam-api-fetch';
export * from './online_exam/index_change/clear-response';