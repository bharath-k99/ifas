import { StyleSheet } from 'react-native';
export default StyleSheet.create({
    drawerHeaderLeft: {
    margin:20,
  },
  backButton: {
    width: 20,
    height: 20,
    marginLeft: 8,
    tintColor:'black'
  },
  backButtonContainer: {
    paddingRight: 15,
    marginLeft: 5
  },
});