export function stringEquality(str1, str2){
    let areEqual = str1.toUpperCase() === str2.toUpperCase();
    return areEqual;
}