// Summary: This function is a model for the timer
export const timerUtil = (totalSeconds, hours, minutes, seconds) =>{
    return{
        totalSeconds: totalSeconds,
        hours: hours,
        minutes: minutes,
        seconds: seconds
    };
};